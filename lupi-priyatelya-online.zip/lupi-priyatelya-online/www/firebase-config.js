// Вставь сюда конфигурацию своего проекта Firebase (Project settings → Your apps → Web app).
// Это публичная клиентская конфигурация; секретные ключи сюда НЕ добавляй.
window.FIREBASE_CONFIG = {
  apiKey: "ВСТАВЬ_API_KEY",
  authDomain: "ТВОЙ-ПРОЕКТ.firebaseapp.com",
  projectId: "ТВОЙ_PROJECT_ID",
  storageBucket: "ТВОЙ-ПРОЕКТ.firebasestorage.app",
  messagingSenderId: "ВСТАВЬ_SENDER_ID",
  appId: "ВСТАВЬ_APP_ID"
};
